Company Memory Database

Purpose:

Store all important company knowledge.

Include:

- Winning tender strategies
- Lost tender reasons
- Supplier performance history
- Cost estimation mistakes
- Procurement mistakes
- Project execution lessons
- Cash flow lessons
- Contract lessons
- Management decisions and outcomes

The objective is to continuously improve future decisions using historical experience.