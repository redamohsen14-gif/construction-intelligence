Lessons Learned Database

Purpose:

Record every mistake, delay, cost overrun,
supplier issue, tender error,
cash flow issue, procurement issue,
and project challenge.

For every event:

Date:
Project:
Issue:
Root Cause:
Financial Impact:
Corrective Action:
Prevention Method: