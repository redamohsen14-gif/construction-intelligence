Company Name:

Country:
Saudi Arabia

Business Type:
General Contracting

Company Stage:
Startup

Employees:
Less than 10

Services:
General Construction
Civil Works
Finishing Works
Infrastructure
MEP Works

Primary Objectives:

1. Protect cash flow.
2. Prevent losses.
3. Build sustainable profitability.
4. Improve tender accuracy.
5. Build supplier network.
6. Create institutional knowledge.